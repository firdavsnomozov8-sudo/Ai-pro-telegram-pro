import json, sqlite3
from pathlib import Path

DATA=Path("data/english-dictionary.jsonl")
DB=Path("data/vocab.sqlite")
BATCH=1000

def unique(items):
    return list(dict.fromkeys(x for x in items if x))

def main():
    if not DATA.exists():
        raise SystemExit("Dataset missing: run python download_dataset.py")
    DB.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(DB)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("CREATE TABLE IF NOT EXISTS vocab(id INTEGER PRIMARY KEY,word TEXT,word_norm TEXT,pos TEXT,definition TEXT,examples TEXT,ipa TEXT)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_vocab_norm ON vocab(word_norm)")
    batch=[]; inserted=0; skipped=0
    with DATA.open(encoding="utf-8") as f:
        for line in f:
            try:
                o=json.loads(line)
                if o.get("lang") not in (None,"English"): skipped+=1; continue
                word=(o.get("word") or "").strip()
                if not word: skipped+=1; continue
                defs=[]; ex=[]
                for s in o.get("senses") or []:
                    defs += [x.strip() for x in (s.get("glosses") or []) if isinstance(x,str) and x.strip()]
                    ex += [x.get("text","").strip() for x in (s.get("examples") or []) if isinstance(x,dict) and x.get("text")]
                sounds=[x.get("ipa","") for x in (o.get("sounds") or []) if isinstance(x,dict) and x.get("ipa")]
                batch.append((word,word.casefold(),o.get("pos","")," | ".join(unique(defs)[:10])," | ".join(unique(ex)[:5])," / ".join(unique(sounds))))
                if len(batch)>=BATCH:
                    con.executemany("INSERT INTO vocab(word,word_norm,pos,definition,examples,ipa) VALUES(?,?,?,?,?,?)",batch)
                    con.commit(); inserted+=len(batch); batch=[]; print(f"{inserted:,} imported")
            except Exception: skipped+=1
    if batch:
        con.executemany("INSERT INTO vocab(word,word_norm,pos,definition,examples,ipa) VALUES(?,?,?,?,?,?)",batch); con.commit(); inserted+=len(batch)
    total=con.execute("SELECT COUNT(*) FROM vocab").fetchone()[0]
    con.close()
    print(f"Finished: this run {inserted:,}; skipped {skipped:,}; total in DB {total:,}")
if __name__=="__main__": main()
