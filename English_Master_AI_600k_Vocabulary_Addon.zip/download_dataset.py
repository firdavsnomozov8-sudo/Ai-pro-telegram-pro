import os
import urllib.request

# Official raw-data page: https://kaikki.org/dictionary/rawdata.html
# Confirm current English JSONL URL there if this URL changes.
DATA_URL = "https://kaikki.org/dictionary/English/kaikki.org-dictionary-English.jsonl"
OUT = os.path.join("data", "english-dictionary.jsonl")
os.makedirs("data", exist_ok=True)

if os.path.exists(OUT) and os.path.getsize(OUT):
    print("Dataset already downloaded:", OUT, os.path.getsize(OUT), "bytes")
else:
    print("Downloading English dictionary dataset; this can take a while...")
    try:
        urllib.request.urlretrieve(DATA_URL, OUT)
        print("Saved:", OUT, os.path.getsize(OUT), "bytes")
    except Exception:
        if os.path.exists(OUT): os.remove(OUT)
        print("Download failed. Check the current English JSONL link at kaikki.org/dictionary/rawdata.html")
        raise
