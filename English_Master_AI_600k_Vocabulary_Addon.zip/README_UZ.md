# English Master AI — 600K+ Vocabulary Add-on

Bu ZIP botga katta lug'at qidiruv modulini qo'shish uchun. **600,000+ so'z/ma'no dataset ZIP ichida emas**: katta Kaikki JSONL fayli alohida yuklanadi, keyin SQLite bazaga import qilinadi.

## 1. Dataset
`python download_dataset.py`
Agar Kaikki download URL o'zgargan bo'lsa, `download_dataset.py` ichidagi `DATA_URL`ni https://kaikki.org/dictionary/rawdata.html sahifasidagi English JSONL havolasiga almashtiring.

## 2. SQLite import
`python import_vocab.py`
Natija: `data/vocab.sqlite`. Dataset juda katta bo'lishi mumkin; serverda disk va RAM/vaqt yetarli bo'lishi kerak.

## 3. Express backend
`npm install better-sqlite3`
`vocab_api.js`ni `server.js` yoniga qo'ying va server.js ichida:
```js
const vocabRouter = require('./vocab_api');
app.use('/api/vocab', vocabRouter);
```
API: `GET /api/vocab/search?q=hello&limit=20`, `GET /api/vocab/health`.

`vocab_test.html`ni public papkaga joylasangiz, API qidiruvni UI orqali sinashingiz mumkin.
Kaikki/Wiktionary attribution va litsenziya talablarini dataset sahifasidan tekshiring.
