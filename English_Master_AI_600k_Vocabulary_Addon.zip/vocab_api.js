// Express router for English Master AI vocabulary
const express=require('express'), path=require('path'), Database=require('better-sqlite3');
const router=express.Router();
const dbPath=process.env.VOCAB_DB || path.join(__dirname,'data','vocab.sqlite');
let db;
function database(){if(!db) db=new Database(dbPath,{readonly:true,fileMustExist:true});return db;}
router.get('/health',(_req,res)=>{try{res.json({ok:true,total:database().prepare('SELECT COUNT(*) n FROM vocab').get().n});}catch(e){res.status(503).json({ok:false,error:e.message});}});
router.get('/search',(req,res)=>{
 const q=String(req.query.q||'').trim(), limit=Math.min(Math.max(parseInt(req.query.limit||'20',10)||20,1),50);
 if(!q)return res.status(400).json({error:'q parameter required'});
 try{
  const rows=database().prepare("SELECT word,pos,definition,examples,ipa FROM vocab WHERE word_norm LIKE ? ORDER BY CASE WHEN word_norm=? THEN 0 ELSE 1 END LIMIT ?").all(q.toLowerCase()+'%',q.toLowerCase(),limit);
  res.json({query:q,count:rows.length,results:rows});
 }catch(e){res.status(503).json({error:'Vocabulary database not ready',detail:e.message});}
});
module.exports=router;
